    select 
	'[ '
	+ '''id'' => ''' + CAST(ROW_NUMBER() OVER (ORDER BY [IdDmQuocGia]) as VARCHAR) + ''''
	+ ', ''ma_quocgia'' => ''' + ISNULL(maquocgia, '') + ''''
	+ ', ''ten_donvitinh'' => ''' + ISNULL(tenquocgia, '') + ''''
	+ ', ''ten_quocgia'' => ' + '$now' + ''
	+ '],'
  from [HIS_TAMTHAN].[dbo].[DmQuocGia]