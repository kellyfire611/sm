<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStoreSanphamNhomLoaiRelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('store_sanpham_nhom_loai_rel', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('sanpham_id');
            $table->unsignedInteger('sanpham_nhom_id');
            $table->unsignedInteger('sanpham_loai_id');
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('sanpham_id')->references('id')->on('store_sanpham');
            $table->foreign('sanpham_nhom_id')->references('id')->on('store_sanpham_nhom');
            $table->foreign('sanpham_loai_id')->references('id')->on('store_sanpham_loai');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('store_sanpham_nhom_loai_rel');
    }
}
