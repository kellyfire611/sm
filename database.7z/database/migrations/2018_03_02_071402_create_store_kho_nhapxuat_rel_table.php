<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStoreKhoNhapxuatRelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('store_kho_nhapxuat_rel', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('tu_kho_id');
            $table->unsignedInteger('den_kho_id')->nullable();
            $table->unsignedInteger('nhapxuat_id')->nullable();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('tu_kho_id')->references('id')->on('store_kho');
            $table->foreign('den_kho_id')->references('id')->on('store_kho');
            $table->foreign('nhapxuat_id')->references('id')->on('store_nhapxuat');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('store_kho_nhapxuat_rel');
    }
}
