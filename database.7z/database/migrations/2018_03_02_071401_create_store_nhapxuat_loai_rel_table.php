<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStoreNhapxuatLoaiRelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('store_nhapxuat_loai_rel', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('nhapxuat_id');
            $table->unsignedInteger('nhapxuat_loai_id');
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('nhapxuat_id')->references('id')->on('store_nhapxuat');
            $table->foreign('nhapxuat_loai_id')->references('id')->on('store_nhapxuat_loai');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('store_nhapxuat_loai_rel');
    }
}
