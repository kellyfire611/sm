<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHrmNoichonRelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hrm_noichon_rel', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('quocgia_id');
            $table->unsignedInteger('tinhthanh_id');
            $table->unsignedInteger('quanhuyen_id');
            $table->unsignedInteger('xaphuong_id');
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('quocgia_id')->references('id')->on('hrm_quocgia');
            $table->foreign('tinhthanh_id')->references('id')->on('hrm_tinhthanh');
            $table->foreign('quanhuyen_id')->references('id')->on('hrm_quanhuyen');
            $table->foreign('xaphuong_id')->references('id')->on('hrm_xaphuong');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hrm_noichon_rel');
    }
}
